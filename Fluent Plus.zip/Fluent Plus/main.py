"""Fluent Plus — pywebview entry point."""

from __future__ import annotations

import sys
from pathlib import Path

import webview

from api import Api


def _frontend_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "frontend"
    return Path(__file__).resolve().parent / "frontend"


def main() -> None:
    api = Api()
    index_html = _frontend_dir() / "index.html"

    window = webview.create_window(
        title="Fluent Plus",
        url=index_html.as_uri(),
        width=720,
        height=640,
        min_size=(560, 520),
        js_api=api,
    )
    webview.start(debug=False)


if __name__ == "__main__":
    main()
