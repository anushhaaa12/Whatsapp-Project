# Fluent Plus

Windows desktop app for triggering Jenkins test automation builds from a native UI.

## Phase 1 scope

- Jenkins API token setup (saved locally)
- Run Test form with JIRA Stories, Test Type, and Azure OpenAI Model
- In-memory build status (Success / Failed) with polling

## Setup

1. Install Python 3.11+
2. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Run the app:

```bash
python main.py
```

On first launch you'll be prompted for your **Jenkins username** and **API token**. They are saved to:

`%APPDATA%\FluentPlus\token.cfg`

## Build executable

```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name FluentPlus --add-data "frontend;frontend" main.py
```

The `.exe` will be in the `dist/` folder.

## Jenkins job parameters

The job must accept these build parameters:

- `JIRA_STORIES`
- `TEST_TYPE`
- `AZURE_OPENAI_MODEL`

## Configuration

Jenkins URL and job name are fixed defaults in `config.py` for all users:

| Setting | Value |
|---------|-------|
| `JENKINS_URL` | `https://ci4.cisco.com` |
| `JENKINS_JOB_NAME` | `Testing/job/Fluent_Pilot_Groups/job/Finance_Transformation_Enablement_Team/job/main` |

Each user provides their own **username** and **API token** at login.
