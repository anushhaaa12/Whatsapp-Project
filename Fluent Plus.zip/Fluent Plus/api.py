"""Python API exposed to the frontend via pywebview js_api."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

import token_manager
from config import JENKINS_JOB_NAME, JENKINS_URL, POLL_INTERVAL_SECONDS
from jenkins_client import (
    JenkinsError,
    format_duration,
    get_build_info,
    trigger_build,
    validate_credentials,
)
from token_manager import Credentials


@dataclass
class RunContext:
    jira_story: str = ""
    test_type: str = ""
    model: str = ""


@dataclass
class BuildState:
    status: str = "idle"  # idle | running | success | failed | error
    build_number: int | None = None
    duration: str = ""
    message: str = ""
    context: RunContext = field(default_factory=RunContext)


class Api:
    """Bridge between JavaScript and Python backend."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._state = BuildState()
        self._poll_thread: threading.Thread | None = None
        self._stop_polling = threading.Event()

    def has_token(self) -> bool:
        return token_manager.has_credentials()

    def save_token(self, username: str, api_token: str) -> dict[str, Any]:
        username = (username or "").strip()
        api_token = (api_token or "").strip()

        if not username:
            return {"success": False, "error": "Jenkins username is required."}
        if not api_token:
            return {"success": False, "error": "API token is required."}

        ok, error = validate_credentials(username, api_token)
        if not ok:
            return {"success": False, "error": error or "Credential validation failed."}

        try:
            token_manager.save_credentials(username, api_token)
        except ValueError as exc:
            return {"success": False, "error": str(exc)}

        return {"success": True}

    def clear_token(self) -> dict[str, Any]:
        token_manager.delete_credentials()
        self._reset_state()
        return {"success": True}

    def get_build_status(self) -> dict[str, Any]:
        with self._lock:
            state = self._state
            return {
                "status": state.status,
                "build_number": state.build_number,
                "duration": state.duration,
                "message": state.message,
                "jira_story": state.context.jira_story,
                "test_type": state.context.test_type,
                "model": state.context.model,
            }

    def trigger_jenkins_build(
        self,
        jira_story: str,
        test_type: str,
        model: str,
    ) -> dict[str, Any]:
        jira_story = (jira_story or "").strip()
        test_type = (test_type or "").strip()
        model = (model or "").strip()

        if not jira_story or not test_type or not model:
            return {
                "success": False,
                "error": "All fields are required.",
            }

        credentials = token_manager.read_credentials()
        if not credentials:
            return {
                "success": False,
                "error": "No credentials saved. Please sign in first.",
            }

        with self._lock:
            if self._state.status == "running":
                return {
                    "success": False,
                    "error": "A build is already running.",
                }

            self._stop_polling.set()
            if self._poll_thread and self._poll_thread.is_alive():
                self._poll_thread.join(timeout=0.5)

            self._stop_polling = threading.Event()
            self._state = BuildState(
                status="running",
                message="Build triggered…",
                context=RunContext(
                    jira_story=jira_story,
                    test_type=test_type,
                    model=model,
                ),
            )

        thread = threading.Thread(
            target=self._run_build,
            args=(credentials, jira_story, test_type, model),
            daemon=True,
        )
        self._poll_thread = thread
        thread.start()

        return {"success": True}

    def get_app_info(self) -> dict[str, str]:
        credentials = token_manager.read_credentials()
        return {
            "jenkins_url": JENKINS_URL,
            "job_name": JENKINS_JOB_NAME,
            "username": credentials.username if credentials else "",
        }

    def _run_build(
        self,
        credentials: Credentials,
        jira_story: str,
        test_type: str,
        model: str,
    ) -> None:
        try:
            build_number = trigger_build(
                credentials.username,
                credentials.api_token,
                jira_story,
                test_type,
                model,
            )
        except JenkinsError as exc:
            self._set_state(status="error", message=str(exc))
            return

        self._set_state(
            status="running",
            build_number=build_number,
            message=f"Build #{build_number} running…",
        )

        while not self._stop_polling.is_set():
            try:
                info = get_build_info(
                    credentials.username,
                    credentials.api_token,
                    build_number,
                )
            except JenkinsError as exc:
                self._set_state(status="error", message=str(exc))
                return

            if info.building:
                self._set_state(
                    status="running",
                    build_number=build_number,
                    message=f"Build #{build_number} running…",
                )
                self._stop_polling.wait(POLL_INTERVAL_SECONDS)
                continue

            duration = format_duration(info.duration_ms)
            if info.result == "SUCCESS":
                self._set_state(
                    status="success",
                    build_number=build_number,
                    duration=duration,
                    message="Build completed successfully.",
                )
            else:
                result_label = info.result or "FAILED"
                self._set_state(
                    status="failed",
                    build_number=build_number,
                    duration=duration,
                    message=f"Build finished with status: {result_label}.",
                )
            return

    def _set_state(self, **kwargs: Any) -> None:
        with self._lock:
            for key, value in kwargs.items():
                setattr(self._state, key, value)

    def _reset_state(self) -> None:
        with self._lock:
            self._state = BuildState()
