"""Application configuration — fixed Jenkins targets for all users."""

# Jenkins server base URL (no trailing slash)
JENKINS_URL = "https://ci4.cisco.com"

# Nested job path (no leading/trailing slash)
JENKINS_JOB_NAME = (
    "Testing/job/Fluent_Pilot_Groups/job/"
    "Finance_Transformation_Enablement_Team/job/main"
)

# How often to poll build status (seconds)
POLL_INTERVAL_SECONDS = 5
