"""Jenkins REST API client — trigger builds and poll status."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urljoin

import requests
from requests.auth import HTTPBasicAuth

from config import JENKINS_JOB_NAME, JENKINS_URL


class JenkinsError(Exception):
    """Raised when a Jenkins API call fails."""


@dataclass
class BuildInfo:
    build_number: int
    result: str | None
    building: bool
    duration_ms: int
    url: str


def _auth(username: str, api_token: str) -> HTTPBasicAuth:
    return HTTPBasicAuth(username, api_token)


def _base_url() -> str:
    return JENKINS_URL.rstrip("/") + "/"


def _job_url(path: str) -> str:
    """
    Build the Jenkins job URL.

    Supports two config formats:
    - Full nested path: Testing/job/Fluent_Pilot_Groups/job/main
    - Simple name/path: my-job or folder/my-job
    """
    path = path.strip("/")
    if "/job/" in path:
        # Already a Jenkins nested job path — just prepend job/
        job_path = f"job/{path}"
    else:
        segments = path.split("/")
        job_path = "/".join(f"job/{segment}" for segment in segments)
    return urljoin(_base_url(), f"{job_path}/")


def validate_credentials(username: str, api_token: str) -> tuple[bool, str | None]:
    """Lightweight check: GET /api/json. Returns (ok, error_message)."""
    url = urljoin(_base_url(), "api/json")
    try:
        response = requests.get(
            url,
            auth=_auth(username, api_token),
            timeout=15,
            headers={"Accept": "application/json"},
        )
    except requests.RequestException as exc:
        return False, f"Could not reach Jenkins: {exc}"

    if response.status_code == 401:
        return False, "Invalid username or API token."
    if response.status_code == 403:
        return False, "Access denied. Check your credentials."
    if not response.ok:
        return False, f"Jenkins returned HTTP {response.status_code}."

    return True, None


def trigger_build(
    username: str,
    api_token: str,
    jira_story: str,
    test_type: str,
    model: str,
) -> int:
    """
    Trigger buildWithParameters and wait for the build number from the queue.
    Returns the assigned build number.
    """
    job_url = _job_url(JENKINS_JOB_NAME)
    trigger_url = urljoin(job_url, "buildWithParameters")

    params = {
        "JIRA_STORIES": jira_story,
        "TEST_TYPE": test_type,
        "AZURE_OPENAI_MODEL": model,
    }

    try:
        response = requests.post(
            trigger_url,
            auth=_auth(username, api_token),
            params=params,
            timeout=30,
            allow_redirects=False,
        )
    except requests.RequestException as exc:
        raise JenkinsError(f"Failed to trigger build: {exc}") from exc

    if response.status_code not in (200, 201):
        raise JenkinsError(
            f"Failed to trigger build (HTTP {response.status_code}). "
            "Check job access and parameters."
        )

    queue_url = response.headers.get("Location")
    if not queue_url:
        raise JenkinsError("Jenkins did not return a queue location.")

    return _wait_for_build_number(username, api_token, queue_url)


def _wait_for_build_number(
    username: str,
    api_token: str,
    queue_url: str,
    timeout: int = 120,
) -> int:
    """Poll the queue item until Jenkins assigns a build number."""
    api_url = queue_url.rstrip("/") + "/api/json"
    deadline = time.time() + timeout

    while time.time() < deadline:
        try:
            response = requests.get(
                api_url,
                auth=_auth(username, api_token),
                timeout=15,
                headers={"Accept": "application/json"},
            )
        except requests.RequestException as exc:
            raise JenkinsError(f"Queue poll failed: {exc}") from exc

        if not response.ok:
            raise JenkinsError(f"Queue poll failed (HTTP {response.status_code}).")

        data: dict[str, Any] = response.json()
        executable = data.get("executable")
        if executable and executable.get("number") is not None:
            return int(executable["number"])

        if data.get("cancelled"):
            raise JenkinsError("Build was cancelled while waiting in queue.")

        time.sleep(2)

    raise JenkinsError("Timed out waiting for Jenkins to start the build.")


def get_build_info(username: str, api_token: str, build_number: int) -> BuildInfo:
    """Fetch current build status from Jenkins."""
    build_url = urljoin(_job_url(JENKINS_JOB_NAME), f"{build_number}/api/json")

    try:
        response = requests.get(
            build_url,
            auth=_auth(username, api_token),
            timeout=15,
            headers={"Accept": "application/json"},
        )
    except requests.RequestException as exc:
        raise JenkinsError(f"Status poll failed: {exc}") from exc

    if not response.ok:
        raise JenkinsError(f"Status poll failed (HTTP {response.status_code}).")

    data: dict[str, Any] = response.json()
    return BuildInfo(
        build_number=build_number,
        result=data.get("result"),
        building=bool(data.get("building", False)),
        duration_ms=int(data.get("duration") or 0),
        url=str(data.get("url") or ""),
    )


def format_duration(duration_ms: int) -> str:
    """Format Jenkins duration (milliseconds) as a human-readable string."""
    if duration_ms <= 0:
        return "—"
    total_seconds = duration_ms // 1000
    minutes, seconds = divmod(total_seconds, 60)
    if minutes:
        return f"{minutes}m {seconds}s"
    return f"{seconds}s"
