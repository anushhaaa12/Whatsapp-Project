"""Read/write local Jenkins credentials (username + API token)."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

APP_DIR_NAME = "FluentPlus"
CREDENTIALS_FILENAME = "token.cfg"


@dataclass
class Credentials:
    username: str
    api_token: str


def _credentials_path() -> Path:
    appdata = os.environ.get("APPDATA")
    if appdata:
        base = Path(appdata) / APP_DIR_NAME
    else:
        base = Path.home() / APP_DIR_NAME
    base.mkdir(parents=True, exist_ok=True)
    return base / CREDENTIALS_FILENAME


def has_credentials() -> bool:
    return read_credentials() is not None


def read_credentials() -> Credentials | None:
    path = _credentials_path()
    if not path.is_file():
        return None

    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        return None

    try:
        data = json.loads(raw)
        username = str(data.get("username", "")).strip()
        api_token = str(data.get("api_token", "")).strip()
    except json.JSONDecodeError:
        # Legacy plain-text token files are no longer supported.
        return None

    if not username or not api_token:
        return None

    return Credentials(username=username, api_token=api_token)


def save_credentials(username: str, api_token: str) -> None:
    username = username.strip()
    api_token = api_token.strip()
    if not username:
        raise ValueError("Username is required")
    if not api_token:
        raise ValueError("API token is required")

    payload = {"username": username, "api_token": api_token}
    _credentials_path().write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )


def delete_credentials() -> None:
    path = _credentials_path()
    if path.is_file():
        path.unlink()
