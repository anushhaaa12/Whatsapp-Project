(function () {
  "use strict";

  const POLL_MS = 2000;

  const tokenScreen = document.getElementById("token-screen");
  const runScreen = document.getElementById("run-screen");
  const changeTokenBtn = document.getElementById("change-token-btn");

  const tokenForm = document.getElementById("token-form");
  const usernameInput = document.getElementById("jenkins-username");
  const usernameError = document.getElementById("username-error");
  const tokenInput = document.getElementById("api-token");
  const tokenError = document.getElementById("token-error");
  const saveTokenBtn = document.getElementById("save-token-btn");

  const runForm = document.getElementById("run-form");
  const jiraInput = document.getElementById("jira-stories");
  const testTypeInput = document.getElementById("test-type");
  const modelInput = document.getElementById("azure-model");
  const runBtn = document.getElementById("run-btn");
  const jenkinsInfo = document.getElementById("jenkins-info");

  const statusPanel = document.getElementById("status-panel");
  const statusIndicator = document.getElementById("status-indicator");
  const statusLabel = document.getElementById("status-label");
  const statusJira = document.getElementById("status-jira");
  const statusTestType = document.getElementById("status-test-type");
  const statusModel = document.getElementById("status-model");
  const statusBuildRow = document.getElementById("status-build-row");
  const statusBuild = document.getElementById("status-build");
  const statusDurationRow = document.getElementById("status-duration-row");
  const statusDuration = document.getElementById("status-duration");
  const statusMessage = document.getElementById("status-message");

  let pollTimer = null;

  function pyApi() {
    return window.pywebview && window.pywebview.api;
  }

  function waitForApi(callback) {
    if (pyApi()) {
      callback();
      return;
    }
    window.addEventListener("pywebviewready", callback, { once: true });
  }

  function showScreen(screen) {
    tokenScreen.classList.add("hidden");
    runScreen.classList.add("hidden");

    if (screen === "token") {
      tokenScreen.classList.remove("hidden");
      changeTokenBtn.classList.add("hidden");
    } else {
      runScreen.classList.remove("hidden");
      changeTokenBtn.classList.remove("hidden");
    }
  }

  function showFieldError(input, errorEl, message) {
    input.classList.add("input-error");
    errorEl.textContent = message;
    errorEl.classList.remove("hidden");
  }

  function clearFieldError(input, errorEl) {
    input.classList.remove("input-error");
    errorEl.classList.add("hidden");
  }

  function validateRunForm() {
    let valid = true;

    if (!jiraInput.value.trim()) {
      showFieldError(jiraInput, document.getElementById("jira-error"), "This field is required.");
      valid = false;
    } else {
      clearFieldError(jiraInput, document.getElementById("jira-error"));
    }

    if (!testTypeInput.value.trim()) {
      showFieldError(testTypeInput, document.getElementById("test-type-error"), "This field is required.");
      valid = false;
    } else {
      clearFieldError(testTypeInput, document.getElementById("test-type-error"));
    }

    if (!modelInput.value.trim()) {
      showFieldError(modelInput, document.getElementById("model-error"), "This field is required.");
      valid = false;
    } else {
      clearFieldError(modelInput, document.getElementById("model-error"));
    }

    return valid;
  }

  function setStatusPanelClass(status) {
    statusPanel.classList.remove(
      "status-running",
      "status-success",
      "status-failed",
      "status-error"
    );

    if (status === "running") {
      statusPanel.classList.add("status-running");
    } else if (status === "success") {
      statusPanel.classList.add("status-success");
    } else if (status === "failed") {
      statusPanel.classList.add("status-failed");
    } else if (status === "error") {
      statusPanel.classList.add("status-error");
    }
  }

  function statusLabelText(status) {
    switch (status) {
      case "running":
        return "Running…";
      case "success":
        return "Success";
      case "failed":
        return "Failed";
      case "error":
        return "Error";
      default:
        return "";
    }
  }

  function updateStatusPanel(data) {
    if (!data || data.status === "idle") {
      statusPanel.classList.add("hidden");
      return;
    }

    statusPanel.classList.remove("hidden");
    setStatusPanelClass(data.status);
    statusLabel.textContent = statusLabelText(data.status);

    statusJira.textContent = data.jira_story || "—";
    statusTestType.textContent = data.test_type || "—";
    statusModel.textContent = data.model || "—";

    if (data.build_number) {
      statusBuildRow.classList.remove("hidden");
      statusBuild.textContent = "#" + data.build_number;
    } else {
      statusBuildRow.classList.add("hidden");
    }

    if (data.duration && data.status !== "running") {
      statusDurationRow.classList.remove("hidden");
      statusDuration.textContent = data.duration;
    } else {
      statusDurationRow.classList.add("hidden");
    }

    statusMessage.textContent = data.message || "";
  }

  function setFormDisabled(disabled) {
    jiraInput.disabled = disabled;
    testTypeInput.disabled = disabled;
    modelInput.disabled = disabled;
    runBtn.disabled = disabled;
  }

  async function pollBuildStatus() {
    const api = pyApi();
    if (!api) return;

    try {
      const data = await api.get_build_status();
      updateStatusPanel(data);

      if (data.status === "running") {
        setFormDisabled(true);
      } else if (data.status === "success" || data.status === "failed" || data.status === "error") {
        setFormDisabled(false);
        stopPolling();
      }
    } catch (err) {
      console.error("Status poll failed:", err);
    }
  }

  function startPolling() {
    stopPolling();
    pollTimer = setInterval(pollBuildStatus, POLL_MS);
    pollBuildStatus();
  }

  function stopPolling() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  async function initApp() {
    const api = pyApi();
    if (!api) return;

    try {
      const info = await api.get_app_info();
      const userLabel = info.username ? " · Signed in as " + info.username : "";
      jenkinsInfo.textContent =
        "Jenkins job: " + (info.job_name || "—") + " @ " + (info.jenkins_url || "—") + userLabel;
    } catch (err) {
      jenkinsInfo.textContent = "";
    }

    const hasToken = await api.has_token();
    if (hasToken) {
      showScreen("run");
    } else {
      showScreen("token");
    }
  }

  function validateLoginForm() {
    let valid = true;

    if (!usernameInput.value.trim()) {
      showFieldError(usernameInput, usernameError, "Username is required.");
      valid = false;
    } else {
      clearFieldError(usernameInput, usernameError);
    }

    if (!tokenInput.value.trim()) {
      showFieldError(tokenInput, tokenError, "API token is required.");
      valid = false;
    } else {
      clearFieldError(tokenInput, tokenError);
    }

    return valid;
  }

  tokenForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    if (!validateLoginForm()) {
      return;
    }

    const username = usernameInput.value.trim();
    const token = tokenInput.value.trim();

    saveTokenBtn.disabled = true;
    saveTokenBtn.textContent = "Validating…";

    try {
      const result = await pyApi().save_token(username, token);
      if (!result.success) {
        showFieldError(tokenInput, tokenError, result.error || "Could not save credentials.");
        return;
      }
      usernameInput.value = "";
      tokenInput.value = "";
      showScreen("run");
      initApp();
    } catch (err) {
      showFieldError(tokenInput, tokenError, "Unexpected error saving credentials.");
      console.error(err);
    } finally {
      saveTokenBtn.disabled = false;
      saveTokenBtn.textContent = "Save & Continue";
    }
  });

  runForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    if (!validateRunForm()) {
      return;
    }

    const api = pyApi();
    if (!api) return;

    runBtn.disabled = true;
    runBtn.textContent = "Starting…";

    try {
      const result = await api.trigger_jenkins_build(
        jiraInput.value.trim(),
        testTypeInput.value.trim(),
        modelInput.value.trim()
      );

      if (!result.success) {
        updateStatusPanel({
          status: "error",
          jira_story: jiraInput.value.trim(),
          test_type: testTypeInput.value.trim(),
          model: modelInput.value.trim(),
          message: result.error || "Failed to start build.",
        });
        setFormDisabled(false);
        return;
      }

      setFormDisabled(true);
      startPolling();
    } catch (err) {
      updateStatusPanel({
        status: "error",
        message: "Unexpected error starting build.",
      });
      setFormDisabled(false);
      console.error(err);
    } finally {
      runBtn.disabled = false;
      runBtn.textContent = "RUN";
    }
  });

  changeTokenBtn.addEventListener("click", async function () {
    const api = pyApi();
    if (!api) return;

    stopPolling();
    await api.clear_token();
    usernameInput.value = "";
    tokenInput.value = "";
    clearFieldError(usernameInput, usernameError);
    clearFieldError(tokenInput, tokenError);
    updateStatusPanel({ status: "idle" });
    setFormDisabled(false);
    showScreen("token");
    usernameInput.focus();
  });

  [usernameInput, tokenInput].forEach(function (input) {
    input.addEventListener("input", function () {
      const errorEl = input.id === "jenkins-username" ? usernameError : tokenError;
      clearFieldError(input, errorEl);
    });
  });

  [jiraInput, testTypeInput, modelInput].forEach(function (input) {
    input.addEventListener("input", function () {
      const errorId = input.id === "jira-stories"
        ? "jira-error"
        : input.id === "test-type"
          ? "test-type-error"
          : "model-error";
      clearFieldError(input, document.getElementById(errorId));
    });
  });

  waitForApi(initApp);
})();
